package com.augury.aggregation.domain;



import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter

public class Session {
	
	@JsonInclude(Include.NON_NULL) 
	private Sample a;
	
	@JsonInclude(Include.NON_NULL) 
	private Sample b;
	
	public Session() {
		super();
		a = null;
		b = null;
	}
	
	public Session(Sample s) {
		a = new Sample(s);
		b = null;
	}
	
	public Session(Sample s1, Sample s2) {
		a = new Sample(s1);
		b = new Sample(s2);
	}
	
	public void addSample(Sample s) {
		if (a == null)
			a = new Sample(s);
		else {
			if (b == null)
				b = new Sample(s);
			}	
	}
}

