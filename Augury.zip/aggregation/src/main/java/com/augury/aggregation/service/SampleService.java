package com.augury.aggregation.service;

import java.util.Optional;

import com.augury.aggregation.domain.Sample;
import com.augury.aggregation.domain.Session;

public interface SampleService {
	public Optional<Session> getSessionBySample(Sample sample);
	public Optional<Session> getSessionBySampleWithLag(Sample sample);
}
