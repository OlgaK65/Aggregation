package com.augury.aggregation.domain;

import java.io.Serializable;
import java.util.Random;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;

import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor

@Entity
public class Sample implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue
	@JsonIgnore
	private Long id;
	
	@NotBlank
	private String mashineId;
	
	@NotBlank
	private String epId;
	
	private Long timestamp;
	
	@Min(value = 0, message = "measurementValue >= 0")
	@Max(value = 100, message = "measurementValue <= 100")
	private Integer measurementValue;
	
	public Sample(String mashineId, String epId) {
		this.mashineId = mashineId;
		this.epId = epId;
		
	    timestamp = System.currentTimeMillis();
	    measurementValue =  new Random().nextInt(101);
	}

	public Sample(Sample s) {
		this.mashineId = s.getMashineId();
		this.epId = s.getEpId();
		this.timestamp = s.getTimestamp();
		this.measurementValue = s.getMeasurementValue();
	}
	
	@Override
	public String toString() {
		return "" + mashineId + ";" + epId + ";" + timestamp + ";" + measurementValue + ";";
	}    	
}
