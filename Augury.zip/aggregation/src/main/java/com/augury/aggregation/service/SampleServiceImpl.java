package com.augury.aggregation.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.augury.aggregation.dao.SampleRepository;
import com.augury.aggregation.domain.Aggregator;
import com.augury.aggregation.domain.Sample;
import com.augury.aggregation.domain.Session;

@Service
public class SampleServiceImpl implements SampleService {
	
	@Autowired 
	SampleRepository repository;
	
	public Optional<Session> getSessionBySample(Sample sample){	
		Aggregator aggr = new Aggregator(repository);
		return aggr.aggregate(sample);
	}
	
	public Optional<Session> getSessionBySampleWithLag(Sample sample){	
		Aggregator aggr = new Aggregator(repository);
		return aggr.aggregateWithLag(sample);
	}
}
