package com.augury.aggregation.controller;

import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.augury.aggregation.domain.Sample;
import com.augury.aggregation.domain.Session;
import com.augury.aggregation.service.SampleService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;

@RestController
@RequestMapping("/api")
@Tag(name="SampleController", description="Controller description")


public class SampleController {
	
	@Autowired
	SampleService service;
	
	@Operation(summary = "Creates session", description = "Creates session with exactly two samples")
	@PutMapping("/aggregate")
	public ResponseEntity<?> getSession(@Valid @RequestBody Sample sample)  {	
		
		 Optional<Session> session = service.getSessionBySample(sample);
		 	 
		 return Optional.of(session)
		            .map(result -> new ResponseEntity<>(
		                result,
		                HttpStatus.OK))
		            .orElse(new ResponseEntity<>(HttpStatus.NOT_FOUND));
	}
	
	@Operation(summary = "Creates session with lag", description = "Creates session with one or two samples")
	@PutMapping("/aggregate_with_lag")
	public ResponseEntity<?> getSessionWithLag(@Valid @RequestBody Sample sample)  {		
		 Optional<Session> session = service.getSessionBySampleWithLag(sample);
	 	 
		 return Optional.of(session)
		            .map(result -> new ResponseEntity<>(
		                result,
		                HttpStatus.OK))
		            .orElse(new ResponseEntity<>(HttpStatus.NOT_FOUND));
	}
}
