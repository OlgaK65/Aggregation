package com.augury.aggregation.domain;

import java.util.Optional;

import com.augury.aggregation.dao.SampleRepository;
import lombok.NoArgsConstructor;

@NoArgsConstructor

public class Aggregator {
	
	static final Long MAX_LAG = 7200000L;
	SampleRepository repository;
	
	public Aggregator(SampleRepository repository) {
		this.repository = repository;
	}
	
	public Optional<Session> aggregate(Sample s) {
		
		Iterable<Sample> sampleList = repository.findByMashineId(s.getMashineId());
		
		for(Sample smp : sampleList) {		
			if(smp.getEpId().compareTo(s.getEpId()) != 0) {
				repository.deleteById(smp.getId());
				return Optional.of(new Session(smp,s));
			} else {
				smp.setTimestamp(s.getTimestamp());
				smp.setMeasurementValue(s.getMeasurementValue());
				repository.save(smp);
				return Optional.empty();
			}			
		}
			
		repository.save(s);					
		return Optional.empty();
	}
	
	public Optional<Session> aggregateWithLag(Sample s) {
		Iterable<Sample> sampleList = repository.findByMashineId(s.getMashineId());
		
		for(Sample smp : sampleList) {		
			if(smp.getEpId().compareTo(s.getEpId()) != 0) {
				repository.deleteById(smp.getId());
				if(s.getTimestamp() - smp.getTimestamp() <= MAX_LAG)
					return Optional.of(new Session(smp,s));
				else
					return Optional.of(new Session(smp));
					
			} else {
				smp.setTimestamp(s.getTimestamp());
				smp.setMeasurementValue(s.getMeasurementValue());
				repository.save(smp);
				return Optional.empty();
			}			
		}
			
		repository.save(s);						
		return Optional.empty();
	}
}
