package com.augury.aggregation.domain;

import static org.junit.jupiter.api.Assertions.*;

import java.util.Arrays;
import java.util.Optional;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.boot.test.context.SpringBootTest;

import com.augury.aggregation.dao.SampleRepository;

@SpringBootTest
class AggregatorTest {

	@Mock
	SampleRepository repository;
	
	@Test
	void aggregate_test() {
	
		Sample sample1 = new Sample("mashine_1_ABCDEF", "EC_1");
		sample1.setTimestamp(100500L);
		sample1.setMeasurementValue(57);
		
		Sample sample2 = new Sample("mashine_2_ABCDEF", "EC_2");
		sample2.setTimestamp(100501L);
		sample2.setMeasurementValue(99);
		
	    Iterable<Sample> sample_list = Arrays.asList(sample1, sample2);
		
		Sample sample3 = new Sample("mashine_1_ABCDEF", "EC_3");
		sample3.setTimestamp(300502L);
		sample3.setMeasurementValue(25);
			
		Mockito.when(repository.findByMashineId("mashine_1_ABCDEF"))
						.thenReturn(sample_list);
		
		Aggregator aggr = new Aggregator(repository);
		Optional<Session> session = aggr.aggregate(sample3);
		
		if(session.isPresent()){
			assertEquals("EC_1", session.get().getA().getEpId());
			assertEquals("EC_3", session.get().getB().getEpId());
		}	
		else
			fail("Got no session!"); 
	}
	
	@Test
	void aggregate_with_lag_test() {
		Sample sample1 = new Sample("mashine_1_ABCDEF", "EC_1");
		sample1.setTimestamp(100500L);
		sample1.setMeasurementValue(57);
		
		Sample sample2 = new Sample("mashine_2_ABCDEF", "EC_2");
		sample2.setTimestamp(200501L);
		sample2.setMeasurementValue(99);
		
	    Iterable<Sample> sample_list = Arrays.asList(sample1, sample2);
		
		Sample sample3 = new Sample("mashine_1_ABCDEF", "EC_3");
		sample3.setTimestamp(400502L);
		sample3.setMeasurementValue(25);
			
		Mockito.when(repository.findByMashineId("mashine_1_ABCDEF"))
						.thenReturn(sample_list);
		
		Aggregator aggr = new Aggregator(repository);
		Optional<Session> session = aggr.aggregateWithLag(sample3);
		
		if(session.isPresent()){
			assertEquals("EC_1", session.get().getA().getEpId());
			assertNull(session.get().getB());
		}	
		else
			fail("Got no session!"); 
	}
}
