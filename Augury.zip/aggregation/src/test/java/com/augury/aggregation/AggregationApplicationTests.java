package com.augury.aggregation;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AggregationApplicationTests {

	@Test
	void contextLoads() {
	}

}
